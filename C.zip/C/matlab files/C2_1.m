% Laurens Van de Walle
% recursive HDL filter

teller = [1 3 3 1];
noemer = [105 -213 155 -39];

figure(1);
freqz(teller, noemer);
figure(2);
zplane(teller, noemer);

%% 
% 3rd order butterworth LDL

fc = 1;
fs = 2;

teller = [1 3 3 1];
noemer = [105 -213 155 -39];

[b, a] = butter(3, fc, 'low', 's');
[T, N] = bilinear(b, a, fs);

figure(1);
freqz(T, N);
figure(2);
zplane(T, N);