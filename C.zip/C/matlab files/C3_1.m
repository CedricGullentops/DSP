% Laurens Van de Walle
% 8e orde Cauer filter

fc = 300;
rimp = 0.5;
speratt = 50;
fs = 4000;

wn = fc/(fs/2);

[z, p, k] = ellip(8, rimp, speratt, wn);
sos = zp2sos(z, p, 1);

fvtool(sos, 'Analysis', 'freq');