% Opgave 1
a= 625
b= 62,5
c= 250
d= 125
p= 1000
q= 750
r= 8000
n= 64
T = (n-1)/r
t = linspace(0,T,n)

x = a*sin(2*pi*p*t)+ b*sin(2*pi*q*t)